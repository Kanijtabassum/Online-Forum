<footer class="blog-footer">
    <p>Personal Project by:<br><br> <a class="btn btn-sm btn-outline-secondary" href="/">Kanij</a> <a class="btn btn-sm btn-outline-secondary" href="/">Memi</a> <a class="btn btn-sm btn-outline-secondary" href="/">Chamak</a></p>
    <p>
    	<a href="#">Back to top</a>
    </p>
</footer>