@extends('layouts.master')

@section('content')

	<div class="col-md-8">
		
		<h1>About</h1>
		<hr>
		<p class="lead">
			This Forum is for the problem solvers. Anyone who has a knack for programming can join this forum and share there knowledge and views about competitive programming and problem solving. They can post Tutorials or helpful thoughts and also comment on them. Hopefully by shareing their thoughts they will help build the community and make it stronger.
		</p>
	</div>

@endsection