<?php

namespace Tests\Feature;
use App\Post;
use Tests\TestCase;
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;



class ExampleTest extends TestCase
{
     use DatabaseTransactions;

    /**
     * A basic test example.
     *
     * @return void
     */
    
    //navigation to home page

    public function testURLforGuestUserCanSeeForumIndex()
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

     //navigation to about page

     public function testAbout()
    {
        $response = $this->get('/about');

        $response->assertSee("About");
    }


    //navigation to Posts without login

     public function testShowPostWithoutlogedIn()
    {
        $response = $this->post('/posts/{post}');

        $response->assertSee("Online");
        // $post = factory('App\Post')->create();
        // $response = $this->get('/posts/{post}');
        // $response->assertSee('$post->title');
        
    }



    //navigation to CreatePost without login => Error

    public function testCreatePostWithoutLogin()
    {
        $response = $this->get('/createPost');

        $response->assertStatus(404);
    }

}
