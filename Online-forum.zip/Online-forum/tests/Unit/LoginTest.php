<?php

namespace Tests\Feature;

use App\User;
use Tests\TestCase;
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class LoginTest extends TestCase
{

    use DatabaseTransactions;
    /**
     * A basic test example.
     *
     * @return void
     */
    public function testURL()
    {
       $response = $this->call('GET','/login');
       $this->assertEquals(200, $response->status()); //check url response is correct
    }

    public function testBlankFields()
    {
        $user = factory(User::class)->create();
        $response = $this->post('/login',[
         'email' => $user->eamil,                //submitting form with empty field
        'password' => '',
        
        ]);
       //$this->assertEqual(true);
        $response->assertSessionHasErrors();
       	
    }

//      public function testwrongValues()
//     {
//         $this->visit('/login')
//         ->type('kanij','email')
//         ->type('12345','password')
//         ->press('Login')
//        	->seePageIs('/login'); //submitting form with incorrect value
//     }

 

    public function testMisMatchData()
    {
        $user = factory(User::class)->create();
        $response = $this->post('/login',[
         'email' => $user->eamil,
        'password' => 'invalid',
        
        ]);
        $response->assertSessionHasErrors(); //submitting form with wrong password
        //$response->assertRedirect('/login');
    }

    public function testCorrectData()
    {
        $user = factory(User::class)->create();
        $response = $this->post('/login',[
    
        'email' => $user->eamil,
        'password' => '12345',
        
        ]);
        $response->assertStatus(302);
        $response = $this->actingAs($user)->withSession(['foo' => 'bar'])->get('/login');
        $response->assertRedirect('/home');

    }

    public function test_user_cannot_view_a_login_from_when_authenticated()
    {
        $user = factory(User::class)->make();
        $response = $this->actingAs($user)->get('/login');
        $response->assertRedirect('/home');
    }

     public function testLogoutUser()
    {
        $user = factory(User::class)->create();
        $response = $this->actingAs($user)->post('/logout');
    
         $response->assertStatus(405);
        
        
    }



}