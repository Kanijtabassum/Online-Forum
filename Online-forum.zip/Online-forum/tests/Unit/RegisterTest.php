<?php

namespace Tests\Unit;
use App\User;
use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;

class RegisterTest extends TestCase
{

   //use DatabaseTransactions;
    /**
     * A basic test example.
     *
     * @return void
     */
    public function testURL()
    {
       $response = $this->call('GET','register');
       $this->assertEquals(200, $response->status()); //check url response is correct
    }



    public function testRegistrationWithValidUser()
    {
      $user = factory(User::class)->make();
      $response = $this->post('/register',[
      	'name' => $user->name,
      	'email' => $user->eamil,
      	'password' => '12345',
      	'password_confirmation' => '12345',  //submitting form with valid confirm password
      ]);
      $response->assertStatus(302);
      //$this->seeIsAuthenticated();
    }


    public function testRegistrationWithInvalidUser()
    {
      $user = factory(User::class)->make();
      $response = $this->post('/register',[
        'name' => $user->name,
        'email' => $user->eamil,
        'password' => '12345',
        'password_confirmation' => 'invalid',    //submitting form with Invalid confirm password
      ]);
     $response->assertSessionHasErrors();
      //$this->seeIsAuthenticated();
    }


public function testRegistrationWithBlankvalues()
    {
      $user = factory(User::class)->make();
      $response = $this->post('/register',[
        'name' => $user->name,
        'email' => $user->eamil,
        'password' => '12345',
        'password_confirmation' => '',    //submitting form with Blank confirm password
      ]);
     $response->assertSessionHasErrors();
      //$this->seeIsAuthenticated();
    }





}
