<?php

namespace Tests\Feature;

use App\User;
use App\Post;
use Tests\TestCase;
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;

class BlogTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
     public function testCreatePostWithLogedInURL()
    {
       $response = $this->call('GET','/posts/create');
       $this->assertEquals(500, $response->status()); //check url response is correct
    }



    public function testCreatePostWithValidData()
    {
        $post = factory(User::class)->create();
        $response = $this->post('/posts/create',[

        'title' => $post->title,
        'body' => $post->body,
        
        ]);
        
         $response->assertStatus(405);

    }


     public function testCreatePostWithInvalidData()
    {
        $post = factory(User::class)->create();
        $response = $this->post('/posts/create',[

        'title' => $post->title,
        'body' =>'invalid',                 //submitting form with invalid description
        
        ]);
        
        $response->assertStatus(405); 
        //$this->expectException(InvalidArgumentException::class);
 
       

    }




     public function testCreatePostWithBlankData()
    {
        $post = factory(User::class)->create();
        $response = $this->post('/posts/create',[

        'title' => $post->title,
        'body' =>'',                 //submitting form with blank description
        
        ]);
        
         $response->assertStatus(405);       
     

    }




    public function testCreateCommentWithValidData()
    {
        $post = factory(User::class)->create();
        $response = $this->post('/posts/{post}/comments',[

        'body' => $post->body,
        
        ]);
        
        $response->assertStatus(404); 

    }



}
