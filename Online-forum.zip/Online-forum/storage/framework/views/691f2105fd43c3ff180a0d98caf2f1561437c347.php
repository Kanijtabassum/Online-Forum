<?php $__env->startSection('content'); ?>

	<div class="col-md-8 blog-main">
		<h3 class="blog-post-title"><?php echo e($post->title); ?></h3>

		<p class="blog-post-meta">
  			<?php echo e($post->user->name); ?> on
    		<?php echo e($post->created_at->toFormattedDateString()); ?>

  		</p>
		<?php echo e($post->body); ?>


		<hr>

	  	<div class="comments">

	  		<ul class="list-group">
	    		<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    			<li class="list-group-item">
	    				<strong>
	    					<?php echo e($comment->user->name); ?> on
	    					<?php echo e($comment->created_at->diffForHumans()); ?>: &nbsp;
	    				</strong>
	    				<?php echo e($comment->body); ?>

	    			</li>
	    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    	</ul>
	    </div>

	    <hr>

	    <div class="card">
	    	<div class="card-body">
	    		<form method="POST" action="/posts/<?php echo e($post->id); ?>/comments">

	    			<?php echo e(csrf_field()); ?>


	    			<div class="form-group">
	    				<textarea name="body" placeholder="Your comment here." class="form-control" ></textarea>
	    			</div>

	    			<div class="form-group">
		  				<button type="submit" class="btn btn-default">Add Comment</button>
		  			</div>
	    		</form>

	    		<?php echo $__env->make('layouts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    	</div>
	    </div>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>